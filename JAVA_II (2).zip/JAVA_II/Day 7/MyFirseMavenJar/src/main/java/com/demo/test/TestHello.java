package com.demo.test;

public class TestHello {
   public static void main(String[] args) {
	System.out.println("Hello ");
}
}
